import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import FileManager from "@/components/FileManager";

export default function FilesPage() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-foreground/60">Loading...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center max-w-md">
          <p className="text-foreground mb-4">Please log in to manage your portfolio files</p>
          <Button onClick={() => setLocation("/")} variant="outline">
            Return to Home
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-white border-b border-border sticky top-0 z-40">
        <div className="container py-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-4 gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Portfolio
          </Button>
          <h1 className="text-3xl font-bold text-foreground">Portfolio File Manager</h1>
          <p className="text-foreground/60 mt-2">Upload and manage your portfolio files, case studies, and documents</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        <Tabs defaultValue="case-studies" className="w-full">
          <TabsList className="bg-muted border border-border mb-8">
            <TabsTrigger value="case-studies">Case Studies</TabsTrigger>
            <TabsTrigger value="resume">Resume & CV</TabsTrigger>
            <TabsTrigger value="testimonials">Testimonials</TabsTrigger>
            <TabsTrigger value="other">Other Files</TabsTrigger>
          </TabsList>

          <TabsContent value="case-studies" className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                Upload case study PDFs, screenshots, or reports to showcase your work
              </p>
            </div>
            <FileManager category="case-study" />
          </TabsContent>

          <TabsContent value="resume" className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                Upload your resume, CV, or professional credentials
              </p>
            </div>
            <FileManager category="resume" />
          </TabsContent>

          <TabsContent value="testimonials" className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                Upload client testimonials, reviews, or recommendation letters
              </p>
            </div>
            <FileManager category="testimonial" />
          </TabsContent>

          <TabsContent value="other" className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-900">
                Upload any other portfolio-related files
              </p>
            </div>
            <FileManager category="other" />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
