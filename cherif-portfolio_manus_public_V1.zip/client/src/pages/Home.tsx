import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowRight, Mail, Linkedin, ExternalLink, TrendingUp, BarChart3, Globe, Zap } from "lucide-react";
import { useState } from "react";
import { AnimatedCounter } from "@/components/AnimatedCounter";
import { CaseStudiesCarousel } from "@/components/CaseStudiesCarousel";

/**
 * Design System: Warm Professional Storytelling
 * - Color Palette: Cream (#faf8f5), Terracotta (#d97706), Sage Green (#84a59d), Deep Brown (#2d2520)
 * - Typography: Playfair Display (headlines), Merriweather (body), Inter (captions)
 * - Layout: Asymmetric, flowing content blocks with generous whitespace
 * - Interactions: Smooth transitions, purposeful animations, editorial feel
 */

interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  image: string;
  description: string;
  metrics?: string[];
  platforms?: string[];
}

const portfolioItems: PortfolioItem[] = [
  {
    id: "google-ads-ecommerce",
    title: "Ecommerce - Google Ads Optimization",
    category: "Paid Marketing",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310419663030567616/2YhBxqd8JaL2MQs9Zmtjnk/Google%20Ads%20Ecommerce_a7953edc.jpg",
    description: "Optimized high-spend Google Ads campaigns for ecommerce with advanced conversion tracking and audience targeting strategies.",
    metrics: ["Improved ROAS", "Reduced CPC", "Scaled conversions"],
    platforms: ["Google Ads", "GA4"],
  },
  {
    id: "meta-liwa",
    title: "App Marketing - Meta Ads Growth",
    category: "Paid Marketing",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310419663030567616/2YhBxqd8JaL2MQs9Zmtjnk/Meta%20Liwa%20Portfolio_c18c327a.png",
    description: "Managed high-budget Meta Ads campaigns for app user acquisition across multiple geos with sophisticated targeting and creative optimization.",
    metrics: ["61+ campaigns", "151K+ impressions", "88K+ reach", "2.22 CPM"],
    platforms: ["Meta", "Google Ads", "TikTok", "Snapchat"],
  },
  {
    id: "real-estate-meta",
    title: "Real Estate Lead Generation - Meta Ads",
    category: "Paid Marketing",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310419663030567616/2YhBxqd8JaL2MQs9Zmtjnk/RealEstate_Meta_Campaigns_20c5db5b.webp",
    description: "Designed lead generation frameworks generating thousands of qualified leads using Meta Ads with multiple active campaigns. Achieved low cost-per-lead through creative optimization and audience targeting.",
    metrics: ["816 Total Leads", "DZD 167-191 Cost per Lead", "DZD 125K+ Total Spend"],
    platforms: ["Meta Ads", "CRM"],
  },
  {
    id: "linkedin-strategy",
    title: "LinkedIn B2B Acquisition Strategy",
    category: "Paid Marketing",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310419663030567616/2YhBxqd8JaL2MQs9Zmtjnk/LinkedIn%20Ads%20%28CSA%29_f42b9310.png",
    description: "Developed LinkedIn acquisition campaigns for B2B lead generation with strategic audience targeting.",
    metrics: ["Qualified leads", "High-value prospects", "B2B focus"],
    platforms: ["LinkedIn Ads"],
  },
  {
    id: "analytics-dashboard",
    title: "Looker Studio Analytics Dashboard",
    category: "Strategy & Analytics",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310419663030567616/2YhBxqd8JaL2MQs9Zmtjnk/Report%20Looker%20Studio_537576ee.png",
    description: "Built comprehensive Looker Studio dashboards for multi-channel marketing analytics and KPI reporting.",
    metrics: ["Real-time reporting", "Multi-source data", "Custom metrics"],
    platforms: ["Looker Studio", "GA4"],
  },
  {
    id: "hubspot-automation",
    title: "HubSpot Marketing Automation Setup",
    category: "Strategy & Analytics",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310419663030567616/2YhBxqd8JaL2MQs9Zmtjnk/HubSpot_Report_Updated_d2b4254b.png",
    description: "Implemented HubSpot marketing automation including segmentation, workflows, and custom reporting with comprehensive email delivery and bounce rate analysis.",
    metrics: ["97.5% Delivery Rate", "0.67% Hard Bounce Rate", "Segmentation & Workflows"],
    platforms: ["HubSpot"],
  },
  {
    id: "creative-strategy",
    title: "Creative Strategy & Ad Development",
    category: "Creative Strategy",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310419663030567616/2YhBxqd8JaL2MQs9Zmtjnk/Creatives%20Approach%20_6b2cab67.png",
    description: "Developed strategic creative frameworks and content optimization strategies that balance brand messaging with performance metrics, ensuring ads resonate with target audiences while driving measurable results.",
    metrics: ["Creative strategy", "Audience alignment", "Performance-driven design"],
    platforms: ["Meta", "Google Ads"],
  },
];

const expertise = [
  {
    category: "Paid Advertising",
    skills: ["Meta Ads", "Google Ads", "TikTok Ads", "Campaign Architecture", "Budget Optimization"],
  },
  {
    category: "Analytics & Tracking",
    skills: ["GA4", "Google Tag Manager", "Meta CAPI", "Attribution Modeling", "KPI Dashboards"],
  },
  {
    category: "Growth Systems",
    skills: ["Funnel Optimization", "A/B Testing", "Audience Segmentation", "CAC Reduction"],
  },
  {
    category: "Marketing Automation",
    skills: ["HubSpot", "Workflow Automation", "Lead Nurturing", "Email Strategy"],
  },
];

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredPortfolio =
    selectedCategory === "all"
      ? portfolioItems
      : portfolioItems.filter((item) => item.category === selectedCategory);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container py-4 flex items-center justify-between">
          <div className="font-playfair text-2xl font-bold text-primary">Cherif Eddine</div>
          <div className="hidden md:flex gap-8">
            <a href="#about" className="text-foreground hover:text-primary transition-colors">
              About
            </a>
            <a href="#portfolio" className="text-foreground hover:text-primary transition-colors">
              Portfolio
            </a>
            <a href="#expertise" className="text-foreground hover:text-primary transition-colors">
              Expertise
            </a>
            <a href="#contact" className="text-foreground hover:text-primary transition-colors">
              Contact
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-background to-background/50">
        <div className="relative container py-24 md:py-32">
          <div className="text-center space-y-8 max-w-3xl mx-auto">
            <div className="space-y-4">
              <h1 className="font-playfair text-5xl md:text-6xl font-bold text-foreground leading-tight" style={{color: '#d97706'}}>
                Growth & Marketing Data Specialist
              </h1>
            </div>
            <p className="text-xl text-foreground/80 font-merriweather leading-relaxed">
              Driving acquisition, attribution, and revenue efficiency across multi-channel ecosystems
            </p>
            <p className="text-lg text-foreground/70 font-merriweather leading-relaxed">
              Reduced CAC by 20%+ across multiple markets through acquisition system optimization, attribution modeling, and full-funnel performance analysis.
            </p>
            <p className="text-sm text-muted-foreground mt-6">
              Experience across MENA, EU, and US markets working with startups and established companies.
            </p>
            <div className="flex justify-center gap-4">
              <a
                href="https://www.linkedin.com/in/cherifeddinehaddad/"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-colors"
              >
                Connect on LinkedIn
              </a>
              <a
                href="https://drive.google.com/drive/folders/1AkLIlbMkhXKsuN0knigx7flwsErfp9p6?usp=drive_link"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 border border-primary rounded-xl font-medium text-primary hover:bg-primary/10 transition-colors"
              >
                View Portfolio
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Metrics Section */}
      <section className="py-16 bg-primary/5">
        <div className="container grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="space-y-2">
            <p className="text-3xl md:text-4xl font-playfair font-bold text-primary">
              <AnimatedCounter value="20" suffix="%+" duration={2000} />
            </p>
            <p className="text-foreground/70 font-merriweather">CAC Reduction</p>
          </div>
          <div className="space-y-2">
            <p className="text-3xl md:text-4xl font-playfair font-bold text-primary">
              <AnimatedCounter value="100" suffix="+" duration={2000} />
            </p>
            <p className="text-foreground/70 font-merriweather">Campaigns Managed</p>
          </div>
          <div className="space-y-2">
            <p className="text-3xl md:text-4xl font-playfair font-bold text-primary">
              <AnimatedCounter value="4" suffix="+" duration={2000} />
            </p>
            <p className="text-foreground/70 font-merriweather">Markets (MENA, EU, US)</p>
          </div>
          <div className="space-y-2">
            <p className="text-3xl md:text-4xl font-playfair font-bold text-primary">
              <AnimatedCounter value="80" prefix="$" suffix="K+" duration={2000} />
            </p>
            <p className="text-foreground/70 font-merriweather">Monthly Ad Spend</p>
          </div>

        </div>
      </section>

      {/* How I Drive Growth Section */}
      <section className="py-20 container">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-center mb-4 text-foreground">
            How I Drive Growth
          </h2>
          <p className="text-center text-foreground/60 font-merriweather mb-12 max-w-2xl mx-auto">
            A structured approach combining data, strategy, and continuous optimization across the full marketing funnel
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <div className="p-6 border border-border rounded-xl bg-background hover:shadow-lg hover:border-primary/30 transition-all duration-300 hover:-translate-y-1 group">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                <BarChart3 className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-playfair font-semibold text-lg text-foreground">Tracking & Attribution</h3>
            </div>
            <p className="text-foreground/70 font-merriweather">
              GA4, GTM, Meta CAPI, and event architecture implementation to ensure accurate and reliable data.
            </p>
          </div>
          <div className="p-6 border border-border rounded-xl bg-background hover:shadow-lg hover:border-primary/30 transition-all duration-300 hover:-translate-y-1 group">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                <TrendingUp className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-playfair font-semibold text-lg text-foreground">Acquisition Strategy</h3>
            </div>
            <p className="text-foreground/70 font-merriweather">
              Channel mix optimization across Meta, Google, and TikTok with structured budget allocation and scaling frameworks.
            </p>
          </div>
          <div className="p-6 border border-border rounded-xl bg-background hover:shadow-lg hover:border-primary/30 transition-all duration-300 hover:-translate-y-1 group">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                <Zap className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-playfair font-semibold text-lg text-foreground">Experimentation</h3>
            </div>
            <p className="text-foreground/70 font-merriweather">
              Continuous A/B testing across creatives, audiences, and funnels to identify scalable growth opportunities.
            </p>
          </div>
          <div className="p-6 border border-border rounded-xl bg-background hover:shadow-lg hover:border-primary/30 transition-all duration-300 hover:-translate-y-1 group">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                <Globe className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-playfair font-semibold text-lg text-foreground">Optimization</h3>
            </div>
            <p className="text-foreground/70 font-merriweather">
              Focused on reducing CAC, improving ROAS, and aligning acquisition with long-term value (LTV).
            </p>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20">
        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto items-start">
          {/* LEFT SIDE */}
          <div>
            <h2 className="text-3xl font-bold mb-6 text-foreground">
              Data-Driven Growth Specialist
            </h2>
            <p className="text-foreground/70 font-merriweather mb-4">
              Performance Marketing & Growth Specialist with 5+ years of experience managing multi-channel acquisition across Meta, Google, TikTok, and LinkedIn.
            </p>
            <p className="text-foreground/70 font-merriweather mb-4">
              Proven track record in scaling user acquisition, reducing CAC, and improving ROI through data-driven experimentation and advanced tracking systems.
            </p>
            <p className="text-foreground/70 font-merriweather">
              Experience across MENA, EU, and US markets, working with startups and established companies to build scalable growth systems.
            </p>
          </div>
          {/* RIGHT SIDE */}
          <div className="grid gap-4">
            <div className="p-5 border border-border rounded-xl hover:shadow-md hover:border-primary/40 transition-all duration-300 hover:bg-primary/5">
              <h3 className="font-semibold mb-2 text-foreground">Acquisition Strategy</h3>
              <p className="text-sm text-foreground/70 font-merriweather">
                Multi-channel campaigns across Meta, Google, TikTok, and LinkedIn with structured scaling frameworks.
              </p>
            </div>
            <div className="p-5 border border-border rounded-xl hover:shadow-md hover:border-primary/40 transition-all duration-300 hover:bg-primary/5">
              <h3 className="font-semibold mb-2 text-foreground">Analytics & Tracking</h3>
              <p className="text-sm text-foreground/70 font-merriweather">
                GA4, GTM, CAPI, and attribution systems to ensure accurate performance measurement.
              </p>
            </div>
            <div className="p-5 border border-border rounded-xl hover:shadow-md hover:border-primary/40 transition-all duration-300 hover:bg-primary/5">
              <h3 className="font-semibold mb-2 text-foreground">Growth Optimization</h3>
              <p className="text-sm text-foreground/70 font-merriweather">
                Funnel optimization, A/B testing, and performance improvements focused on CAC and ROI.
              </p>
            </div>
            <div className="p-5 border border-border rounded-xl hover:shadow-md hover:border-primary/40 transition-all duration-300 hover:bg-primary/5">
              <h3 className="font-semibold mb-2 text-foreground">Marketing Automation</h3>
              <p className="text-sm text-foreground/70 font-merriweather">
                CRM systems (HubSpot) and lead nurturing workflows to improve conversion and retention.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Decision Impact Section */}
      <section className="py-24 md:py-32 text-center bg-gradient-to-b from-background via-primary/5 to-background">
        <div className="container max-w-3xl mx-auto">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold mb-8 text-foreground leading-tight">
            What I Focus On
          </h2>
          <p className="text-xl md:text-2xl text-foreground/80 font-merriweather leading-relaxed">
            I focus on improving acquisition efficiency, aligning marketing with business outcomes, and building scalable systems that support long-term growth — not just short-term performance.
          </p>
        </div>
      </section>

      {/* Case Studies Section */}
      <section id="portfolio" className="container py-24 md:py-32">
        <div className="space-y-12">
          <div className="text-center space-y-4">
            <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground">Selected Work & Impact</h2>
            <p className="text-foreground/60 font-merriweather max-w-2xl mx-auto">Strategic campaigns that delivered measurable results across acquisition, retention, and revenue optimization</p>
          </div>
          <div className="max-w-3xl mx-auto">
            <CaseStudiesCarousel />
          </div>
        </div>
        <section className="text-center mt-12">
          <p className="text-foreground/70 font-merriweather mb-4">
            Explore more detailed case studies, campaign breakdowns, and project work.
          </p>
          <a
            href="https://drive.google.com/drive/folders/1AkLIlbMkhXKsuN0knigx7flwsErfp9p6?usp=drive_link"
            target="_blank"
            rel="noopener noreferrer"
            className="px-6 py-3 border border-border rounded-xl font-medium inline-block text-foreground hover:bg-primary/5 transition-colors"
          >
            View Full Portfolio
          </a>
        </section>
      </section>

      {/* Spend & Scale Authority Section */}
      <section className="py-12 text-center bg-primary/5">
        <div className="container">
          <p className="text-lg font-merriweather font-medium text-foreground/80">
            Managed and optimized high-volume acquisition campaigns across Meta, Google, and TikTok,
            <br className="hidden md:block" />
            handling significant monthly ad budgets across multiple markets.
          </p>
        </div>
      </section>

      {/* Expertise Section */}
      <section id="expertise" className="py-20">
        <div className="container">
          <h2 className="font-playfair text-3xl font-bold text-center mb-4 text-foreground">
            Expertise and Tools
          </h2>
          <p className="text-foreground/70 font-merriweather text-center mb-12 max-w-2xl mx-auto">
            Focused on acquisition strategy, marketing analytics, and scalable growth systems
          </p>

          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {/* Paid Advertising */}
            <div className="p-6 border border-border rounded-xl hover:shadow-md hover:border-primary/40 transition-all duration-300 hover:bg-primary/5">
              <h3 className="font-semibold text-foreground mb-3">Paid Advertising</h3>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Meta Ads</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Google Ads</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">TikTok Ads</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">LinkedIn Ads</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Snapchat Ads</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">X Ads</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Reddit Ads</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">DV360</span>
              </div>
            </div>

            {/* Analytics */}
            <div className="p-6 border border-border rounded-xl hover:shadow-md hover:border-primary/40 transition-all duration-300 hover:bg-primary/5">
              <h3 className="font-semibold text-foreground mb-3">Analytics & Tracking</h3>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">GA4</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Google Tag Manager</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Meta CAPI</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Attribution Tracking</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Looker Studio</span>
              </div>
            </div>

            {/* Growth */}
            <div className="p-6 border border-border rounded-xl hover:shadow-md hover:border-primary/40 transition-all duration-300 hover:bg-primary/5">
              <h3 className="font-semibold text-foreground mb-3">Growth & Optimization</h3>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">A/B Testing</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Funnel Optimization</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">User Acquisition</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Retention Strategy</span>
              </div>
            </div>

            {/* CRM */}
            <div className="p-6 border border-border rounded-xl hover:shadow-md hover:border-primary/40 transition-all duration-300 hover:bg-primary/5">
              <h3 className="font-semibold text-foreground mb-3">CRM & Automation</h3>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">HubSpot</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">GoHighLevel</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Mailchimp</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Zapier</span>
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">ClickUp</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20">
        <h2 className="text-3xl font-bold text-center mb-12 text-foreground">
          What Clients Say
        </h2>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {/* WeBetterAI */}
          <div className="p-6 border border-border rounded-xl hover:shadow-lg hover:border-primary/30 transition-all duration-300 hover:-translate-y-1">
            <p className="text-foreground/70 font-merriweather mb-4">
              "Chérif combines strategic thinking with strong execution. His work directly improved our visibility and client acquisition in AI-driven solutions."
            </p>
            <a
              href="https://www.webetterai.com/en"
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-foreground hover:text-primary transition"
            >
              We Better AI
            </a>
          </div>
          {/* CSA */}
          <div className="p-6 border border-border rounded-xl hover:shadow-lg hover:border-primary/30 transition-all duration-300 hover:-translate-y-1">
            <p className="text-foreground/70 font-merriweather mb-4">
              "Organized, efficient, and creative. He quickly adapts to new technologies and plays a key role in executing digital marketing campaigns."
            </p>
            <a
              href="https://csa-research.com"
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-foreground hover:text-primary transition"
            >
              CSA Research
            </a>
          </div>
          {/* HIS */}
          <div className="p-6 border border-border rounded-xl hover:shadow-lg hover:border-primary/30 transition-all duration-300 hover:-translate-y-1">
            <p className="text-foreground/70 font-merriweather mb-4">
              "Strong expertise in paid ads and analytics. Reliable, proactive, and consistently delivers quality results with a great team spirit."
            </p>
            <a
              href="https://his.edu.dz"
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-foreground hover:text-primary transition"
            >
              HIS University
            </a>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 max-w-3xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-6 text-foreground">About</h2>

        <p className="text-foreground/70 font-merriweather mb-4">
          I focus on building and scaling acquisition systems that drive sustainable growth — not just short-term performance.
        </p>

        <p className="text-foreground/70 font-merriweather mb-4">
          My approach combines data, experimentation, and structured execution across the full funnel, from user acquisition to retention and conversion optimization.
        </p>

        <p className="text-foreground/70 font-merriweather">
          I work with startups and established companies to improve marketing efficiency, align acquisition with business goals, and create scalable growth frameworks across multiple markets.
        </p>
      </section>

      {/* Final CTA Section */}
      <section id="contact" className="py-20 text-center">
        <h2 className="font-playfair text-3xl font-bold text-foreground mb-4">
          Let's Connect
        </h2>
        <p className="text-foreground/70 font-merriweather mb-8 max-w-xl mx-auto">
          Open to remote roles, consulting, and growth-focused projects across international markets.
        </p>
        <div className="flex justify-center gap-6 flex-wrap">
          <a
            href="https://www.linkedin.com/in/cherifeddinehaddad/"
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-4 bg-primary text-white rounded-xl font-medium hover:bg-primary/90 transition-colors"
          >
            Connect on LinkedIn
          </a>
          <a
            href="mailto:cherifedd@gmail.com"
            className="px-8 py-4 border border-border rounded-xl font-medium text-foreground hover:bg-primary/5 transition-colors"
          >
            Send Email
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background/50">
        <div className="container py-8 text-center text-foreground/60 font-merriweather text-sm">
          <p>© 2026 Cherif Eddine Haddad. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
