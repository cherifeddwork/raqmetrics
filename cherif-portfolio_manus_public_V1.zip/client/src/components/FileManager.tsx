import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Upload, Trash2, Download, FileText, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface FileManagerProps {
  category?: string;
}

export default function FileManager({ category = "case-study" }: FileManagerProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [description, setDescription] = useState("");

  const filesList = trpc.files.list.useQuery();
  const uploadFile = trpc.files.upload.useMutation({
    onSuccess: () => {
      toast.success("File uploaded successfully!");
      setSelectedFile(null);
      setDescription("");
      filesList.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to upload file");
    },
  });
  const deleteFile = trpc.files.delete.useMutation({
    onSuccess: () => {
      toast.success("File deleted successfully!");
      filesList.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete file");
    },
  });

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 50 * 1024 * 1024) {
        toast.error("File size must be less than 50MB");
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      toast.error("Please select a file");
      return;
    }

    setIsUploading(true);
    try {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const base64 = (e.target?.result as string).split(",")[1];
        await uploadFile.mutateAsync({
          fileName: selectedFile.name,
          fileData: base64,
          mimeType: selectedFile.type,
          category,
          description: description || undefined,
          isPublic: true,
        });
      };
      reader.readAsDataURL(selectedFile);
    } catch (error) {
      toast.error("Failed to process file");
    } finally {
      setIsUploading(false);
    }
  };

  const filteredFiles = filesList.data?.filter(f => !category || f.category === category) || [];

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-white border-border">
        <h3 className="text-lg font-bold text-foreground mb-4">Upload Files</h3>
        <div className="space-y-4">
          <div className="border-2 border-dashed border-primary/30 rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
            <input
              type="file"
              onChange={handleFileSelect}
              className="hidden"
              id="file-input"
              accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.gif"
            />
            <label htmlFor="file-input" className="cursor-pointer">
              <Upload className="w-8 h-8 text-primary mx-auto mb-2" />
              <p className="text-foreground font-medium">Click to upload or drag and drop</p>
              <p className="text-sm text-foreground/60">PDF, DOC, XLS, PPT, or images (max 50MB)</p>
            </label>
          </div>

          {selectedFile && (
            <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
              <p className="text-sm font-medium text-foreground">{selectedFile.name}</p>
              <p className="text-xs text-foreground/60">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Description (optional)</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g., Q4 2024 Campaign Results"
              className="w-full px-3 py-2 border border-border rounded-lg text-foreground placeholder-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <Button
            onClick={handleUpload}
            disabled={!selectedFile || isUploading}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            {isUploading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="w-4 h-4 mr-2" />
                Upload File
              </>
            )}
          </Button>
        </div>
      </Card>

      {filteredFiles.length > 0 && (
        <Card className="p-6 bg-white border-border">
          <h3 className="text-lg font-bold text-foreground mb-4">Your Files</h3>
          <div className="space-y-3">
            {filteredFiles.map((file) => (
              <div key={file.id} className="flex items-center justify-between p-4 bg-foreground/5 rounded-lg hover:bg-foreground/10 transition-colors">
                <div className="flex items-center gap-3 flex-1">
                  <FileText className="w-5 h-5 text-primary" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate">{file.fileName}</p>
                    {file.description && (
                      <p className="text-sm text-foreground/60 truncate">{file.description}</p>
                    )}
                    <p className="text-xs text-foreground/50">
                      {(file.fileSize / 1024 / 1024).toFixed(2)} MB • {new Date(file.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2 ml-2">
                  <a
                    href={file.fileUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 hover:bg-primary/10 rounded-lg transition-colors"
                    title="Download"
                  >
                    <Download className="w-4 h-4 text-primary" />
                  </a>
                  <button
                    onClick={() => deleteFile.mutate({ fileId: file.id })}
                    disabled={deleteFile.isPending}
                    className="p-2 hover:bg-red-100 rounded-lg transition-colors disabled:opacity-50"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {filesList.isLoading && (
        <div className="flex justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      )}
    </div>
  );
}
