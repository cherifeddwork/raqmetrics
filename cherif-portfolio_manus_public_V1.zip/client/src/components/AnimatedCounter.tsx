import { useEffect, useRef, useState } from 'react';

interface AnimatedCounterProps {
  value: number | string;
  duration?: number;
  suffix?: string;
  prefix?: string;
}

/**
 * AnimatedCounter component that counts from 0 to the target value
 * Uses intersection observer to trigger animation when element comes into view
 */
export function AnimatedCounter({
  value,
  duration = 2000,
  suffix = '',
  prefix = '',
}: AnimatedCounterProps) {
  const [displayValue, setDisplayValue] = useState('0');
  const [hasAnimated, setHasAnimated] = useState(false);
  const elementRef = useRef<HTMLDivElement>(null);

  // Extract numeric value from string (e.g., "50%+" -> 50, "$80K+" -> 80)
  const getNumericValue = (val: number | string): number => {
    if (typeof val === 'number') return val;
    const match = val.match(/\d+/);
    return match ? parseInt(match[0], 10) : 0;
  };

  const numericValue = getNumericValue(value);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasAnimated) {
            setHasAnimated(true);

            // Animate the counter
            const startTime = Date.now();
            const startValue = 0;

            const animate = () => {
              const now = Date.now();
              const elapsed = now - startTime;
              const progress = Math.min(elapsed / duration, 1);

              // Easing function for smooth animation
              const easeOutQuad = 1 - (1 - progress) * (1 - progress);
              const currentValue = Math.floor(
                startValue + (numericValue - startValue) * easeOutQuad
              );

              setDisplayValue(currentValue.toString());

              if (progress < 1) {
                requestAnimationFrame(animate);
              } else {
                // Ensure final value is set correctly
                setDisplayValue(numericValue.toString());
              }
            };

            requestAnimationFrame(animate);
          }
        });
      },
      {
        threshold: 0.1, // Trigger when 10% of element is visible
      }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => {
      if (elementRef.current) {
        observer.unobserve(elementRef.current);
      }
    };
  }, [numericValue, duration, hasAnimated]);

  return (
    <span ref={elementRef}>
      {prefix}
      {displayValue}
      {suffix}
    </span>
  );
}
