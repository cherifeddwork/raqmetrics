import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { TrendingUp, BarChart3, Globe } from 'lucide-react';

interface CaseStudy {
  id: string;
  title: string;
  company: string;
  icon: 'trending' | 'chart' | 'globe';
  context: string;
  action: string;
  scale: string;
  results: string[];
}

const caseStudies: CaseStudy[] = [
  {
    id: 'yassir',
    title: 'App Growth – Multi-Market Acquisition',
    company: 'Yassir',
    icon: 'trending',
    context: 'Managed large-scale user acquisition campaigns across Algeria and expansion markets (Tunisia, Morocco, Senegal).',
    action: 'Optimized Meta, Google, and TikTok campaigns, improved audience targeting, and implemented data-driven creative testing with deep linking strategies.',
    scale: 'Multi-market campaigns across Algeria, Tunisia, Morocco, and Senegal',
    results: [
      'Reduced CAC by 50%+ across multiple GEOs',
      'Scaled installs and in-app engagement',
      'Improved attribution accuracy and campaign efficiency',
    ],
  },
  {
    id: 'his',
    title: 'Lead Generation & Growth',
    company: 'HIS University',
    icon: 'chart',
    context: 'Built acquisition system for a private university to increase qualified student leads.',
    action: 'Developed full-funnel strategy across Meta, Google, and LinkedIn, optimized landing pages, and implemented email marketing flows.',
    scale: 'National acquisition campaigns with multi-channel funnel',
    results: [
      'Increased qualified leads by 30%',
      'Reduced CPL through funnel optimization',
      'Strengthened inbound acquisition via SEO & email',
    ],
  },
  {
    id: 'csa',
    title: 'B2B Marketing Operations',
    company: 'CSA Research (USA)',
    icon: 'globe',
    context: 'Supported B2B marketing operations and lead generation for a US-based research company.',
    action: 'Implemented HubSpot workflows, improved segmentation, and supported LinkedIn content & gated campaigns.',
    scale: 'B2B international marketing operations (US market)',
    results: [
      'Increased LinkedIn content output by 200%',
      'Improved lead nurturing and marketing efficiency',
      'Enhanced reporting and campaign visibility',
    ],
  },
];

const iconMap = {
  trending: TrendingUp,
  chart: BarChart3,
  globe: Globe,
};

export function CaseStudiesCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);

  useEffect(() => {
    if (!autoPlay) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % caseStudies.length);
    }, 6000); // Auto-advance every 6 seconds

    return () => clearInterval(timer);
  }, [autoPlay]);

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
    setAutoPlay(false);
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % caseStudies.length);
    setAutoPlay(false);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + caseStudies.length) % caseStudies.length);
    setAutoPlay(false);
  };

  const currentStudy = caseStudies[currentIndex];
  const IconComponent = iconMap[currentStudy.icon];

  return (
    <div className="w-full">
      {/* Carousel Container */}
      <div className="relative">
        {/* Slide */}
        <div className="min-h-[500px] flex items-center justify-center">
          <Card className="p-8 border-border hover:shadow-lg hover:border-primary/30 transition-all duration-300 w-full max-w-2xl group">
            <div className="flex items-start gap-4 mb-4">
              <div className="p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors flex-shrink-0">
                <IconComponent className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-playfair text-2xl font-semibold text-foreground">
                  {currentStudy.title}
                </h3>
                <p className="text-sm text-primary font-medium mt-1">{currentStudy.company}</p>
              </div>
            </div>

            <div className="space-y-3 text-foreground/80 font-merriweather">
              <p>
                <strong className="text-foreground">Context:</strong> {currentStudy.context}
              </p>
              <p>
                <strong className="text-foreground">Action:</strong> {currentStudy.action}
              </p>
              <p>
                <strong className="text-foreground">Scale:</strong> {currentStudy.scale}
              </p>
              <div>
                <strong className="text-foreground">Results:</strong>
                <ul className="mt-2 ml-4 space-y-1">
                  {currentStudy.results.map((result, idx) => (
                    <li key={idx}>• {result}</li>
                  ))}
                </ul>
              </div>
            </div>
          </Card>
        </div>

        {/* Navigation Arrows */}
        <button
          onClick={prevSlide}
          className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-12 md:-translate-x-16 p-2 rounded-full hover:bg-primary/10 transition-colors text-primary hover:text-primary/80"
          aria-label="Previous case study"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-12 md:translate-x-16 p-2 rounded-full hover:bg-primary/10 transition-colors text-primary hover:text-primary/80"
          aria-label="Next case study"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* Bullet Navigation */}
      <div className="flex justify-center gap-3 mt-8">
        {caseStudies.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentIndex
                ? 'bg-primary w-8'
                : 'bg-primary/30 hover:bg-primary/50'
            }`}
            aria-label={`Go to case study ${index + 1}`}
            aria-current={index === currentIndex}
          />
        ))}
      </div>

      {/* Slide Counter */}
      <div className="text-center mt-4 text-sm text-foreground/60 font-merriweather">
        {currentIndex + 1} / {caseStudies.length}
      </div>
    </div>
  );
}
