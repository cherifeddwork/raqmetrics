import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, portfolioFiles, InsertPortfolioFile, PortfolioFile } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Portfolio file helpers
export async function createPortfolioFile(file: InsertPortfolioFile): Promise<PortfolioFile | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create portfolio file: database not available");
    return null;
  }

  try {
    const result = await db.insert(portfolioFiles).values(file);
    const fileId = (result[0] as any).insertId;
    const created = await db.select().from(portfolioFiles).where(eq(portfolioFiles.id, fileId));
    return created.length > 0 ? created[0] : null;
  } catch (error) {
    console.error("[Database] Failed to create portfolio file:", error);
    throw error;
  }
}

export async function getPortfolioFilesByUserId(userId: number): Promise<PortfolioFile[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get portfolio files: database not available");
    return [];
  }

  try {
    return await db.select().from(portfolioFiles).where(eq(portfolioFiles.userId, userId));
  } catch (error) {
    console.error("[Database] Failed to get portfolio files:", error);
    throw error;
  }
}

export async function getPublicPortfolioFiles(): Promise<PortfolioFile[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get public portfolio files: database not available");
    return [];
  }

  try {
    return await db.select().from(portfolioFiles).where(eq(portfolioFiles.isPublic, 1));
  } catch (error) {
    console.error("[Database] Failed to get public portfolio files:", error);
    throw error;
  }
}

export async function deletePortfolioFile(fileId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete portfolio file: database not available");
    return false;
  }

  try {
    await db.delete(portfolioFiles).where(eq(portfolioFiles.id, fileId));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete portfolio file:", error);
    throw error;
  }
}
