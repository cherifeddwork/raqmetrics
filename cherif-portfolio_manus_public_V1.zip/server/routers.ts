import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { createPortfolioFile, getPortfolioFilesByUserId, getPublicPortfolioFiles, deletePortfolioFile } from "./db";
import { storagePut } from "./storage";
import { z } from "zod";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  files: router({
    upload: protectedProcedure
      .input(z.object({
        fileName: z.string(),
        fileData: z.string(),
        mimeType: z.string(),
        category: z.string(),
        description: z.string().optional(),
        isPublic: z.boolean().default(true),
      }))
      .mutation(async ({ ctx, input }) => {
        try {
          const buffer = Buffer.from(input.fileData, 'base64');
          const fileSize = buffer.length;

          const timestamp = Date.now();
          const randomSuffix = Math.random().toString(36).substring(2, 8);
          const fileKey = `portfolio/${ctx.user.id}/${input.category}/${timestamp}-${randomSuffix}-${input.fileName}`;

          const { url } = await storagePut(fileKey, buffer, input.mimeType);

          const file = await createPortfolioFile({
            userId: ctx.user.id,
            fileName: input.fileName,
            fileKey,
            fileUrl: url,
            mimeType: input.mimeType,
            fileSize,
            category: input.category,
            description: input.description,
            isPublic: input.isPublic ? 1 : 0,
          });

          if (!file) {
            throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Failed to save file metadata' });
          }

          return file;
        } catch (error) {
          console.error('[Files] Upload error:', error);
          throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'File upload failed' });
        }
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      return await getPortfolioFilesByUserId(ctx.user.id);
    }),

    publicList: publicProcedure.query(async () => {
      return await getPublicPortfolioFiles();
    }),

    delete: protectedProcedure
      .input(z.object({ fileId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const files = await getPortfolioFilesByUserId(ctx.user.id);
        const file = files.find(f => f.id === input.fileId);

        if (!file) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'File not found' });
        }

        const success = await deletePortfolioFile(input.fileId);
        if (!success) {
          throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR', message: 'Failed to delete file' });
        }

        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
